package firstone

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
